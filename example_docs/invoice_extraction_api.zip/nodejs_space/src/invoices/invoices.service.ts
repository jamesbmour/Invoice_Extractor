import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { randomUUID } from 'crypto';
import * as fs from 'fs/promises';
import * as path from 'path';

interface LineItem {
  item: string;
  price: number;
}

interface ExtractionResult {
  vendorName?: string;
  invoiceTotal?: number;
  dueDate?: string;
  lineItems?: LineItem[];
  errorMessage?: string;
}

@Injectable()
export class InvoicesService {
  private readonly logger = new Logger(InvoicesService.name);
  private readonly uploadDir = path.join(process.cwd(), 'uploads');

  constructor(private readonly prisma: PrismaService) {
    this.ensureUploadDirectory();
  }

  private async ensureUploadDirectory() {
    try {
      await fs.mkdir(this.uploadDir, { recursive: true });
      this.logger.log(`Upload directory ready at: ${this.uploadDir}`);
    } catch (error) {
      this.logger.error('Failed to create upload directory', error);
    }
  }

  async uploadInvoice(
    file: Express.Multer.File,
    currency?: string,
  ): Promise<{ jobId: string; status: string }> {
    const jobId = randomUUID();
    const fileName = `${jobId}_${file.originalname}`;
    const filePath = path.join(this.uploadDir, fileName);

    try {
      // Save file to disk
      await fs.writeFile(filePath, file.buffer);
      this.logger.log(`File saved: ${fileName} (${file.size} bytes)`);

      // Create invoice record in database
      const invoice = await this.prisma.invoice.create({
        data: {
          jobId,
          status: 'pending',
          fileName: file.originalname,
          fileSize: file.size,
          filePath,
          currency: currency || null,
        },
      });

      this.logger.log(`Invoice created with jobId: ${jobId}`);

      // Start async processing (no await - fire and forget)
      this.processInvoice(invoice.id, filePath, currency).catch((error) => {
        this.logger.error(`Background processing failed for job ${jobId}`, error);
      });

      return {
        jobId,
        status: 'pending',
      };
    } catch (error) {
      this.logger.error(`Failed to upload invoice for job ${jobId}`, error);
      throw error;
    }
  }

  private async processInvoice(
    invoiceId: number,
    filePath: string,
    currency?: string,
  ): Promise<void> {
    try {
      // Update status to processing
      await this.prisma.invoice.update({
        where: { id: invoiceId },
        data: { status: 'processing' },
      });

      this.logger.log(`Processing invoice ID: ${invoiceId}`);

      // Extract data using LLM
      const extractionResult = await this.extractInvoiceData(filePath, currency);

      // Check if all required fields are present
      const hasError = !extractionResult.vendorName ||
        extractionResult.invoiceTotal === undefined ||
        !extractionResult.dueDate ||
        !extractionResult.lineItems ||
        extractionResult.lineItems.length === 0;

      const status = hasError ? 'failed' : 'completed';

      // Save extraction result
      await this.prisma.extractionresult.create({
        data: {
          invoiceId,
          vendorName: extractionResult.vendorName || null,
          invoiceTotal: extractionResult.invoiceTotal || null,
          dueDate: extractionResult.dueDate ? new Date(extractionResult.dueDate) : null,
          lineItems: extractionResult.lineItems ? (extractionResult.lineItems as any) : undefined,
          errorMessage: extractionResult.errorMessage || (hasError ? 'Failed to extract all required fields from invoice' : null),
        },
      });

      // Update invoice status
      await this.prisma.invoice.update({
        where: { id: invoiceId },
        data: { status },
      });

      this.logger.log(`Invoice ${invoiceId} processing ${status}`);
    } catch (error) {
      this.logger.error(`Error processing invoice ${invoiceId}`, error);

      // Mark as failed
      await this.prisma.extractionresult.create({
        data: {
          invoiceId,
          errorMessage: `Processing error: ${error.message}`,
        },
      });

      await this.prisma.invoice.update({
        where: { id: invoiceId },
        data: { status: 'failed' },
      });
    }
  }

  private async extractInvoiceData(
    filePath: string,
    currency?: string,
  ): Promise<ExtractionResult> {
    try {
      // Read file and convert to base64
      const fileBuffer = await fs.readFile(filePath);
      const base64Data = fileBuffer.toString('base64');
      const ext = path.extname(filePath).toLowerCase();

      // Determine MIME type
      let mimeType = 'application/pdf';
      if (['.jpg', '.jpeg'].includes(ext)) {
        mimeType = 'image/jpeg';
      } else if (ext === '.png') {
        mimeType = 'image/png';
      }

      const dataUrl = `data:${mimeType};base64,${base64Data}`;

      // Prepare prompt for LLM
      const currencyInstruction = currency
        ? `The currency is ${currency}.`
        : 'Determine the currency from the invoice.';

      const prompt = `Extract the following information from this invoice image/PDF and respond in JSON format:

1. vendor_name: The name of the vendor/company issuing the invoice (required)
2. invoice_total: The total amount due as a number (required). ${currencyInstruction}
3. due_date: The payment due date in ISO 8601 format (YYYY-MM-DD) (required)
4. line_items: An array of items with their names and prices (required). Each item should have "item" and "price" fields.

IMPORTANT:
- All fields are required. If you cannot find any of them, set it to null and include an error message.
- Return ONLY valid JSON, no markdown or explanations.
- For line_items, extract all billable items with their individual prices.
- Ensure invoice_total is a number (not a string).
- Ensure due_date is in ISO 8601 format (YYYY-MM-DD).

Example response format:
{
  "vendor_name": "Acme Corporation",
  "invoice_total": 1299.99,
  "due_date": "2026-03-15",
  "line_items": [
    {"item": "Product A", "price": 999.99},
    {"item": "Service B", "price": 300.00}
  ]
}`;

      // Call LLM API with vision capability
      const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.ABACUSAI_API_KEY}`,
        },
        body: JSON.stringify({
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: prompt,
                },
                {
                  type: 'image_url',
                  image_url: {
                    url: dataUrl,
                  },
                },
              ],
            },
          ],
          response_format: { type: 'json_object' },
          stream: false,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`LLM API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error('No content returned from LLM API');
      }

      // Parse JSON response
      const parsed = JSON.parse(content);

      this.logger.log(`Extraction completed: ${JSON.stringify(parsed)}`);

      return {
        vendorName: parsed.vendor_name || null,
        invoiceTotal: parsed.invoice_total || null,
        dueDate: parsed.due_date || null,
        lineItems: parsed.line_items || null,
      };
    } catch (error) {
      this.logger.error('Error extracting invoice data', error);
      return {
        errorMessage: `Extraction failed: ${error.message}`,
      };
    }
  }

  async getJobStatus(jobId: string) {
    const invoice = await this.prisma.invoice.findUnique({
      where: { jobId },
      include: {
        extractionResult: true,
      },
    });

    if (!invoice) {
      throw new NotFoundException(`Job not found: ${jobId}`);
    }

    const response: any = {
      jobId: invoice.jobId,
      status: invoice.status,
      fileName: invoice.fileName,
      fileSize: invoice.fileSize,
      currency: invoice.currency,
      createdAt: invoice.createdAt,
    };

    if (invoice.extractionResult) {
      response.extractionData = {
        vendorName: invoice.extractionResult.vendorName,
        invoiceTotal: invoice.extractionResult.invoiceTotal,
        dueDate: invoice.extractionResult.dueDate?.toISOString(),
        lineItems: invoice.extractionResult.lineItems,
        errorMessage: invoice.extractionResult.errorMessage,
      };
    }

    return response;
  }

  async listInvoices(page: number = 1, limit: number = 10) {
    const skip = (page - 1) * limit;

    const [invoices, total] = await Promise.all([
      this.prisma.invoice.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          extractionResult: true,
        },
      }),
      this.prisma.invoice.count(),
    ]);

    const items = invoices.map((invoice) => ({
      id: invoice.id,
      jobId: invoice.jobId,
      status: invoice.status,
      fileName: invoice.fileName,
      fileSize: invoice.fileSize,
      currency: invoice.currency ?? undefined,
      createdAt: invoice.createdAt,
      vendorName: invoice.extractionResult?.vendorName ?? undefined,
      invoiceTotal: invoice.extractionResult?.invoiceTotal ?? undefined,
      dueDate: invoice.extractionResult?.dueDate?.toISOString(),
      lineItems: invoice.extractionResult?.lineItems as any,
      errorMessage: invoice.extractionResult?.errorMessage ?? undefined,
    }));

    return {
      invoices: items,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }
}

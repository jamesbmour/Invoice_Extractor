import {
  Controller,
  Post,
  Get,
  Param,
  Query,
  UploadedFiles,
  UseInterceptors,
  BadRequestException,
  Body,
  Logger,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiConsumes,
  ApiResponse,
  ApiSecurity,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { InvoicesService } from './invoices.service';
import { UploadInvoiceDto } from './dto/upload-invoice.dto';
import { JobResponseDto } from './dto/job-response.dto';
import { JobStatusDto } from './dto/job-status.dto';
import { InvoiceListResponseDto, PaginationQueryDto } from './dto/invoice-list.dto';

const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/jpg',
  'image/gif',
  'image/webp',
];

@ApiTags('Invoices')
@ApiSecurity('X-API-Key')
@Controller('invoices')
export class InvoicesController {
  private readonly logger = new Logger(InvoicesController.name);

  constructor(private readonly invoicesService: InvoicesService) {}

  @Post('upload')
  @ApiOperation({
    summary: 'Upload invoice files for processing',
    description:
      'Upload one or more invoice files (PDF or images) for automated data extraction. Returns a job ID for tracking the processing status.',
  })
  @ApiConsumes('multipart/form-data')
  @ApiResponse({
    status: 201,
    description: 'Invoice uploaded successfully',
    type: JobResponseDto,
  })
  @ApiResponse({
    status: 400,
    description: 'Invalid file format or size exceeded',
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized - Invalid API key',
  })
  @UseInterceptors(
    FilesInterceptor('files', 10, {
      limits: {
        fileSize: MAX_FILE_SIZE,
      },
    }),
  )
  async uploadInvoice(
    @UploadedFiles() files: Express.Multer.File[],
    @Body() body: UploadInvoiceDto,
  ): Promise<JobResponseDto> {
    if (!files || files.length === 0) {
      throw new BadRequestException('No files uploaded. Please provide at least one invoice file.');
    }

    // Validate file types
    for (const file of files) {
      if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
        throw new BadRequestException(
          `Invalid file type: ${file.mimetype}. Allowed types: PDF, JPEG, PNG, GIF, WEBP`,
        );
      }

      if (file.size > MAX_FILE_SIZE) {
        throw new BadRequestException(
          `File size exceeds 100MB limit: ${file.originalname}`,
        );
      }
    }

    this.logger.log(
      `Uploading ${files.length} file(s). Currency: ${body.currency || 'auto-detect'}`,
    );

    // For MVP, process only the first file
    // In production, you might want to create multiple jobs
    const result = await this.invoicesService.uploadInvoice(files[0], body.currency);

    return {
      jobId: result.jobId,
      status: result.status,
      message: 'Invoice uploaded successfully and queued for processing',
    };
  }

  @Get('jobs/:jobId')
  @ApiOperation({
    summary: 'Get job status and extraction results',
    description:
      'Check the processing status of an invoice extraction job and retrieve the extracted data when completed.',
  })
  @ApiParam({
    name: 'jobId',
    description: 'Job ID returned from the upload endpoint',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  @ApiResponse({
    status: 200,
    description: 'Job status retrieved successfully',
    type: JobStatusDto,
  })
  @ApiResponse({
    status: 404,
    description: 'Job not found',
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized - Invalid API key',
  })
  async getJobStatus(@Param('jobId') jobId: string): Promise<JobStatusDto> {
    this.logger.log(`Fetching status for job: ${jobId}`);
    return await this.invoicesService.getJobStatus(jobId);
  }

  @Get()
  @ApiOperation({
    summary: 'List all processed invoices',
    description:
      'Retrieve a paginated list of all invoices with their extraction results.',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number (starting from 1)',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page (max 100)',
    example: 10,
  })
  @ApiResponse({
    status: 200,
    description: 'Invoice list retrieved successfully',
    type: InvoiceListResponseDto,
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized - Invalid API key',
  })
  async listInvoices(
    @Query() query: PaginationQueryDto,
  ): Promise<InvoiceListResponseDto> {
    this.logger.log(`Listing invoices - Page: ${query.page}, Limit: ${query.limit}`);
    return await this.invoicesService.listInvoices(query.page, query.limit);
  }
}

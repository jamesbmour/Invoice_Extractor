import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsIn } from 'class-validator';

export class UploadInvoiceDto {
  @ApiProperty({
    type: 'array',
    items: {
      type: 'string',
      format: 'binary',
    },
    description: 'Invoice files (PDF or images)',
    required: true,
  })
  files: Express.Multer.File[];

  @ApiProperty({
    description: 'Currency code (e.g., USD, EUR, GBP)',
    example: 'USD',
    required: false,
  })
  @IsOptional()
  @IsIn(['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR'], {
    message: 'Currency must be a valid ISO currency code',
  })
  currency?: string;
}

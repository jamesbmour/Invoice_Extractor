import { ApiProperty } from '@nestjs/swagger';

export class JobResponseDto {
  @ApiProperty({
    description: 'Job ID for tracking the processing status',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  jobId: string;

  @ApiProperty({
    description: 'Current status of the job',
    example: 'pending',
    enum: ['pending', 'processing', 'completed', 'failed'],
  })
  status: string;

  @ApiProperty({
    description: 'Message describing the current state',
    example: 'Invoice uploaded successfully and queued for processing',
  })
  message: string;
}

import { ApiProperty } from '@nestjs/swagger';

class LineItemDto {
  @ApiProperty({ example: 'Product A' })
  item: string;

  @ApiProperty({ example: 99.99 })
  price: number;
}

class ExtractionDataDto {
  @ApiProperty({ example: 'Acme Corporation' })
  vendorName?: string;

  @ApiProperty({ example: 1299.99 })
  invoiceTotal?: number;

  @ApiProperty({ example: '2026-03-15T00:00:00.000Z' })
  dueDate?: string;

  @ApiProperty({ type: [LineItemDto] })
  lineItems?: LineItemDto[];

  @ApiProperty({ example: 'Failed to extract vendor name from invoice' })
  errorMessage?: string;
}

export class JobStatusDto {
  @ApiProperty({
    description: 'Job ID',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  jobId: string;

  @ApiProperty({
    description: 'Current status of the job',
    example: 'completed',
    enum: ['pending', 'processing', 'completed', 'failed'],
  })
  status: string;

  @ApiProperty({
    description: 'File name of the uploaded invoice',
    example: 'invoice_2026.pdf',
  })
  fileName: string;

  @ApiProperty({
    description: 'File size in bytes',
    example: 1048576,
  })
  fileSize: number;

  @ApiProperty({
    description: 'Currency code (if provided)',
    example: 'USD',
    required: false,
  })
  currency?: string;

  @ApiProperty({
    description: 'Timestamp when the job was created',
    example: '2026-02-09T10:30:00.000Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Extracted data from the invoice (available when status is completed)',
    type: ExtractionDataDto,
    required: false,
  })
  extractionData?: ExtractionDataDto;
}

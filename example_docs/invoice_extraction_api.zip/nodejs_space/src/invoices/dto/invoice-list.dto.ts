import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsOptional, IsInt, Min, Max } from 'class-validator';

export class PaginationQueryDto {
  @ApiProperty({
    description: 'Page number (starting from 1)',
    example: 1,
    required: false,
    default: 1,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiProperty({
    description: 'Number of items per page (max 100)',
    example: 10,
    required: false,
    default: 10,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit?: number = 10;
}

class LineItemDto {
  @ApiProperty({ example: 'Product A' })
  item: string;

  @ApiProperty({ example: 99.99 })
  price: number;
}

class InvoiceItemDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  jobId: string;

  @ApiProperty({ example: 'completed' })
  status: string;

  @ApiProperty({ example: 'invoice_2026.pdf' })
  fileName: string;

  @ApiProperty({ example: 1048576 })
  fileSize: number;

  @ApiProperty({ example: 'USD', required: false })
  currency?: string;

  @ApiProperty({ example: '2026-02-09T10:30:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: 'Acme Corporation', required: false })
  vendorName?: string;

  @ApiProperty({ example: 1299.99, required: false })
  invoiceTotal?: number;

  @ApiProperty({ example: '2026-03-15T00:00:00.000Z', required: false })
  dueDate?: string;

  @ApiProperty({ type: [LineItemDto], required: false })
  lineItems?: LineItemDto[];

  @ApiProperty({ example: 'Failed to extract required fields', required: false })
  errorMessage?: string;
}

export class InvoiceListResponseDto {
  @ApiProperty({ type: [InvoiceItemDto] })
  invoices: InvoiceItemDto[];

  @ApiProperty({
    description: 'Pagination metadata',
    example: {
      total: 100,
      page: 1,
      limit: 10,
      totalPages: 10,
    },
  })
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

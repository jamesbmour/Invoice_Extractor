import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { Request, Response, NextFunction } from 'express';

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create(AppModule);

  // Enable validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Enable CORS
  app.enableCors();

  // Swagger configuration
  const swaggerPath = 'api-docs';
  
  // Prevent CDN/browser caching of Swagger docs
  app.use(`/${swaggerPath}`, (req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
    next();
  });

  const config = new DocumentBuilder()
    .setTitle('Invoice Extraction API')
    .setDescription(
      'REST API for extracting structured data from invoice files using AI-powered vision models. Upload invoices in PDF or image format and receive extracted vendor information, totals, due dates, and line items.',
    )
    .setVersion('1.0')
    .addTag('Invoices', 'Invoice upload and extraction endpoints')
    .addApiKey(
      {
        type: 'apiKey',
        name: 'X-API-Key',
        in: 'header',
        description: 'API key for authentication',
      },
      'X-API-Key',
    )
    .build();

  const document = SwaggerModule.createDocument(app, config);
  
  SwaggerModule.setup(swaggerPath, app, document, {
    customSiteTitle: 'Invoice Extraction API',
    customfavIcon: 'https://cdn-icons-png.flaticon.com/512/3143/3143609.png',
    customCss: `
      .swagger-ui .topbar { display: none; }
      .swagger-ui .info .title { font-size: 36px; color: #1a202c; font-weight: 700; }
      .swagger-ui .info .description { font-size: 16px; color: #4a5568; line-height: 1.6; }
      .swagger-ui .scheme-container { background: #f7fafc; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0; }
      .swagger-ui .opblock { border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 16px; }
      .swagger-ui .opblock-tag { font-size: 20px; font-weight: 600; color: #2d3748; }
      .swagger-ui .opblock.opblock-post { border-color: #48bb78; background: #f0fff4; }
      .swagger-ui .opblock.opblock-get { border-color: #4299e1; background: #ebf8ff; }
      .swagger-ui .opblock-summary-method { border-radius: 6px; font-weight: 600; }
      .swagger-ui .btn { border-radius: 6px; font-weight: 600; }
      .swagger-ui .btn.execute { background-color: #4299e1; border-color: #4299e1; }
      .swagger-ui .btn.execute:hover { background-color: #3182ce; }
      .swagger-ui table thead tr th { font-weight: 600; color: #2d3748; }
      body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    `,
  });

  const port = process.env.PORT ?? 3000;
  await app.listen(port);
  
  logger.log(`🚀 Application is running on: http://localhost:${port}`);
  logger.log(`📚 API Documentation available at: http://localhost:${port}/${swaggerPath}`);
  logger.log(`🔑 Don't forget to check the logs for the generated API key!`);
}
bootstrap();

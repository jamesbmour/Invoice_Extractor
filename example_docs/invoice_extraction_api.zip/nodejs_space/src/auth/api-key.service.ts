import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { randomUUID } from 'crypto';

@Injectable()
export class ApiKeyService implements OnModuleInit {
  private readonly logger = new Logger(ApiKeyService.name);

  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    // Create a default API key if none exists
    const existingKeys = await this.prisma.apikey.count();
    
    if (existingKeys === 0) {
      const defaultKey = randomUUID();
      await this.prisma.apikey.create({
        data: {
          key: defaultKey,
          name: 'Default API Key',
        },
      });
      this.logger.log(`Default API key created: ${defaultKey}`);
      this.logger.log('IMPORTANT: Save this API key - you will need it to authenticate requests!');
    }
  }

  async validateApiKey(key: string): Promise<boolean> {
    try {
      const apiKey = await this.prisma.apikey.findUnique({
        where: { key },
      });
      return !!apiKey;
    } catch (error) {
      this.logger.error('Error validating API key', error);
      return false;
    }
  }

  async createApiKey(name: string): Promise<string> {
    const key = randomUUID();
    await this.prisma.apikey.create({
      data: {
        key,
        name,
      },
    });
    this.logger.log(`New API key created: ${name}`);
    return key;
  }
}
